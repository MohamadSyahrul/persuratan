
<?php $__env->startPush('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/pages/simple-datatables.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>Managemen Anggota</h3>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Pages</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Managemen Anggota</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <section class="section">
        <div class="card">
            <div class="card-header">
                <a href="#" class="btn icon btn-primary" data-bs-toggle="modal" data-bs-target="#tambahAnggota">Tambah
                    Anggota</a>

                <!--tambah form Modal -->
                <div class="modal fade text-left" id="tambahAnggota" tabindex="-1" role="dialog"
                    aria-labelledby="myModalLabel33" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="myModalLabel33">Form Tambah Anggota</h4>
                                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                    <i data-feather="x"></i>
                                </button>
                            </div>
                            <form action="<?php echo e(route('managemen-anggota.store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">

                                    <label for="nik">NIK</label>
                                    <div class="form-group">
                                    <input class="form-control" required aria-required="true" id="nik" name="nik"
                                        type="number">
                                    </div>
                                    <label for="nama">Nama</label>
                                    <div class="form-group">
                                    <input class="form-control" required aria-required="true" id="nama" name="nama"
                                        type="text">
                                    </div>
                                    <label for="email">Email</label>
                                    <div class="form-group">
                                    <input class="form-control" required aria-required="true" id="email" name="email"
                                        type="text">
                                    </div>
                                    <label for="foto">Foto</label>
                                    <div class="form-group">
                                    <input type="file" id="input-file-now" name="foto" class="form-control"
                                        data-default-file="" accept="image/*" />
                                    </div>
                                    <label for="ttd">Tanda Tangan</label>
                                    <div class="form-group">
                                    <input type="file" id="input-file-now" name="ttd" class="form-control"
                                        data-default-file="" accept="image/*" />
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                                        <i class="bx bx-x d-block d-sm-none"></i>
                                        <span class="d-none d-sm-block">Close</span>
                                    </button>
                                    <button type="submit" class="btn btn-primary ml-1" data-bs-dismiss="modal">
                                        <i class="bx bx-check d-block d-sm-none"></i>
                                        <span class="d-none d-sm-block">Simpan</span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-striped" id="table1">
                    <thead>
                        <tr>
                            <th>Foto</th>
                            <th>Nik</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>TTD</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $usr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($item->foto): ?>
                                    <div class="avatar avatar-xl">
                                        <img src="<?php echo e(asset('img/profil/'.$item->foto)); ?>" alt="">
                                    </div>  
                                    <?php else: ?>
                                    no image                                        
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($item->nik); ?></td>
                                <td><?php echo e($item->nama); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td>
                                    <?php if($item->ttd): ?>
                                    <div class="avatar avatar-xl">
                                        <img src="<?php echo e(asset('img/profil/'.$item->ttd)); ?>" alt="">
                                    </div>  
                                    <?php else: ?>
                                    no image                                        
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="#" class="btn icon btn-warning" data-bs-toggle="modal"
                                        data-bs-target="#editAnggota<?php echo e($item->id); ?>"><i class="bi bi-pencil-square"></i></a>

                                    <!--Edit form Modal -->
                                    <div class="modal fade text-left" id="editAnggota<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
                                        aria-labelledby="myModalLabel33" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable"
                                            role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title" id="myModalLabel33">Login Form </h4>
                                                    <button type="button" class="close" data-bs-dismiss="modal"
                                                        aria-label="Close">
                                                        <i data-feather="x"></i>
                                                    </button>
                                                </div>
                                                <form action="<?php echo e(route('managemen-anggota.update',$item->id)); ?>" method="post" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('put'); ?>
                                                    <div class="modal-body">
                                                        <label for="nik">NIK</label>
                                                        <div class="form-group">
                                                        <input class="form-control" required aria-required="true" value="<?php echo e($item->nik); ?>" id="nik" name="nik"
                                                            type="number">
                                                        </div>
                                                        <label for="nama">Nama</label>
                                                        <div class="form-group">
                                                        <input class="form-control" required aria-required="true" value="<?php echo e($item->nama); ?>" id="nama" name="nama"
                                                            type="text">
                                                        </div>
                                                        <label for="email">Email</label>
                                                        <div class="form-group">
                                                        <input class="form-control" required aria-required="true" value="<?php echo e($item->email); ?>" id="email" name="email"
                                                            type="text">
                                                        </div>
                                                        <label for="foto">Foto</label>
                                                        <div class="form-group">
                                                        <input type="file" id="input-file-now" name="foto" class="form-control"
                                                            data-default-file="" accept="image/*" />
                                                        </div>
                                                        <label for="ttd">Tanda Tangan</label>
                                                        <div class="form-group">
                                                        <input type="file" id="input-file-now" name="ttd" class="form-control"
                                                            data-default-file="" accept="image/*" />
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-light-secondary"
                                                            data-bs-dismiss="modal">
                                                            <i class="bx bx-x d-block d-sm-none"></i>
                                                            <span class="d-none d-sm-block">Close</span>
                                                        </button>
                                                        <button type="submit" class="btn btn-primary ml-1"
                                                            data-bs-dismiss="modal">
                                                            <i class="bx bx-check d-block d-sm-none"></i>
                                                            <span class="d-none d-sm-block">Update</span>
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    <a href="javascript:;" class="btn icon btn-danger" data-bs-toggle="modal" data-bs-target="#hapus-data<?php echo e($item->id); ?>">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                    <div class="modal fade" id="hapus-data<?php echo e($item->id); ?>" tabindex="-1" role="dialog"
                                        aria-labelledby="hapus-data" aria-hidden="true">
                                        <div class="modal-dialog modal-danger modal-dialog-centered modal-"
                                            role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h6 class="modal-title" id="modal-title-notification">Hapus Data
                                                        User</h6>
                                                    <button type="button" class="btn-close text-dark"
                                                        data-bs-dismiss="modal" aria-label="Close">
                                                        
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('managemen-anggota.destroy', $item->id)); ?>"
                                                        method="POST">
                                                        <?php echo method_field('delete'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <div class="py-3 text-center">
                                                            <i class="ni ni-bell-55 ni-3x"></i>
                                                            <h4 class="text-gradient text-primary mt-4">Apakah Kamu Akan Menghapus Data User <?php echo e($item->nama); ?>

                                                                ?
                                                            </h4>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" class="btn btn-danger">Hapus</button>
                                                            <button type="button"
                                                                class="btn btn-white text-secondary ml-auto"
                                                                data-bs-dismiss="modal">Batal</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('assets/js/extensions/simple-datatables.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\laravel\surat\resources\views/pages/admin/managemenanggota.blade.php ENDPATH**/ ?>