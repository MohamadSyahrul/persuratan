
<?php $__env->startPush('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/pages/simple-datatables.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3><?php echo e($pagename); ?></h3>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Pages</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($pagename); ?></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <section class="section">
        <div class="card">
            <div class="card-header">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <strong>Success!</strong> <?php echo e($message); ?>

                </div>
                <?php endif; ?>
                <a href="javascript:;" class="btn icon icon-left btn-primary" data-bs-toggle="modal"
                    data-bs-target="#tambah-data"><i class="bi bi-send-plus-fill"></i>
                    Tambah Surat Keluar</a>
                
                <div class="modal fade" id="tambah-data" tabindex="-1" role="dialog"
                    aria-labelledby="hapus-data" aria-hidden="true">
                    <div class="modal-dialog modal-danger modal-dialog-centered modal-" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="btn-close text-dark" data-bs-dismiss="modal"
                                    aria-label="Close">
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('createPimpinan')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">
                                        <label for="no_surat-label">No Surat</label>
                                        <div class="form-group">
                                            <input type="text" id="no_surat-label" class="form-control"
                                            placeholder="Masukan No Surat" name="no_surat">
                                        </div>
                                        <label for="perihal-label">Perihal</label>
                                        <div class="form-group">
                                            <input type="text" id="perihal-label" class="form-control"
                                                    placeholder="Masukan Perihal dari Surat" name="perihal">
                                        </div>
                                        <label for="masukan-sifat">Sifat Surat</label>
                                        <div class="form-group">
                                            <input type="text" id="company-column" class="form-control"
                                                    name="sifat" placeholder="Masukan sifat surat">
                                        </div>
                                        <label for="masukan-sifat">Asal Surat</label>
                                        <div class="form-group">
                                            <input type="text" id="company-column" class="form-control"
                                                    name="asal_surat" placeholder="Masukan asal surat">
                                        </div>
                                        <label for="date-surat">Tanggal Surat</label>
                                        <div class="form-group">
                                            <input type="date" id="date-surat" class="form-control"
                                            name="tgl_surat">
                                        </div>
                                        <label for="country-floating">Klasifikasi Surat</label>
                                        <div class="form-group">
                                            <select class="form-select" id="klasifikasi" name="id_klasifikasi" required>
                                                <option>Pilih klasifikasi...</option>
                                                <?php $__currentLoopData = $klasifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->nama_klasifikasi); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <label for="dokumen">Dokumen</label>
                                        <div class="form-group">
                                            <input type="file" id="dokumen" class="form-control"
                                                    name="dokumen" placeholder="Masukan File Surat" required>
                                        </div>
                                        <label for="keterangan">Keterangan</label>
                                        <div class="form-group">
                                            <input type="text" id="keterangan" class="form-control"
                                                    name="keterangan" placeholder="Masukan Keterangan" required>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-light-secondary" data-bs-dismiss="modal">
                                            <i class="bx bx-x d-block d-sm-none"></i>
                                            <span class="d-none d-sm-block">Close</span>
                                        </button>
                                        <button type="submit" class="btn btn-primary ml-1" data-bs-dismiss="modal">
                                            <i class="bx bx-check d-block d-sm-none"></i>
                                            <span class="d-none d-sm-block">Kirim</span>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-striped" id="table1">
                    <thead>
                        <tr>
                            <th>No Surat</th>
                            <th>Tanggal</th>
                            <th>Dokumen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->pembuat->level == 'pimpinan'): ?>
                        <tr>
                            <td><?php echo e($item->no_surat); ?></td>
                            <td><?php echo e($item->tgl_surat); ?></td>
                            <td>
                                <a href="<?php echo e(route('downloadpimpinan', $item->dokumen)); ?>">
                                    <?php echo e($item->dokumen ?? 'dokumen'); ?>

                                </a>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('assets/js/extensions/simple-datatables.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\laravel\surat\resources\views/pages/surat/surat.blade.php ENDPATH**/ ?>