
<?php $__env->startPush('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/pages/simple-datatables.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3><?php echo e($pagename); ?></h3>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Pages</a></li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($pagename); ?></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <section class="section">
        <div class="card">
            <div class="card-header">
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong> <?php echo e($message); ?>

                    </div>   
                <?php endif; ?>
                Data <?php echo e($pagename); ?>

            </div>
            <div class="card-body">
                <table class="table table-striped" id="table1">
                    <thead>
                        <tr>
                            <th>No Surat</th>
                            <th>Nama Penerima</th>
                            <th>Tanggal Surat</th>
                            <th>Dokumen</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->no_surat); ?></td>
                                <td><?php echo e($row->user->nama); ?></td>
                                <td><?php echo e($row->tgl_surat); ?></td>
                                <td>
                                    <a href="<?php echo e(route('downloadDokumen', $row->dokumen)); ?>">
                                        <?php echo e($row->dokumen ?? 'dokumen'); ?>

                                    </a>
                                </td>
                                <td>
                                    <?php if($row->status_surat == 'pending'): ?>
                                        <div class="badge bg-warning"><?php echo e($row->status_surat); ?></div>
                                    <?php endif; ?>
                                    <?php if($row->status_surat == 'disetujui'): ?>
                                    <div class="badge bg-success"><?php echo e($row->status_surat); ?></div>
                                    <?php endif; ?>
                                    <?php if($row->status_surat == 'ditolak'): ?>
                                    <div class="badge bg-danger"><?php echo e($row->status_surat); ?></div>
                                    <?php endif; ?>
                                    <?php if($row->status_surat == 'revisi'): ?>
                                    <div class="badge bg-info"><?php echo e($row->status_surat); ?></div>
                                    <?php endif; ?>

                                </td>
                                <td>
                                    <button class="btn btn-primary dropdown-toggle" type="button"
                                        id="dropdownMenuButtonEmoji" data-bs-toggle="dropdown" aria-haspopup="true"
                                        aria-expanded="false">
                                        <i class="bi bi-file-check-fill"></i>Pilih
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButtonEmoji">
                                        <a class="dropdown-item" href="disetujui/<?php echo e($row->id); ?>"><i class="bi bi-file-earmark-check-fill"></i>
                                            Setujui
                                        </a>
                                        <a class="dropdown-item" href="ditunda/<?php echo e($row->id); ?>"><i class="bi bi-file-earmark-minus-fill"></i>
                                            Tunda
                                        </a>
                                        <a class="dropdown-item" href="ditolak/<?php echo e($row->id); ?>"><i class="bi bi-file-earmark-excel-fill"></i>
                                            Tolak
                                        </a>
                                        <a class="dropdown-item" href="direvisi/<?php echo e($row->id); ?>"><i class="bi bi-file-earmark-plus-fill"></i>
                                            Revisi
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('assets/js/extensions/simple-datatables.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\laravel\surat\resources\views/pages/menyetujui/surat.blade.php ENDPATH**/ ?>