<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('style'); ?>
</head>

<body>
    <div id="app">
        <div id="sidebar" class="active">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div id="main">
            <header class="mb-3">
                <a href="#" class="burger-btn d-block d-xl-none">
                    <i class="bi bi-justify fs-3"></i>
                </a>
            </header>
            <?php echo $__env->yieldContent('content'); ?>
           
        </div>
    </div>

    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html><?php /**PATH C:\Users\user\Documents\laravel\surat\resources\views/layouts/master.blade.php ENDPATH**/ ?>